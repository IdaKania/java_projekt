package gra;

public class Knife extends Item {
    public Knife() {
        name = "Noz";
        rarity = "pospolity";
        desc = "Chroni przed wilkami";
        accuracy = 50;
        damage = 10;
        points = 1;
    }
}
