package gra;

public class Troll extends NPC {
    public Troll() {
        name = "Troll";
        attack = 21;
    }
}
