package gra;

public class Glass extends Item {
    public Glass() {
        name = "Szklo";
        rarity = "pospolity";
        desc = "Odstrasza przed trollami";
        accuracy = 50;
        damage = 10;
        points = 1;
    }
}
