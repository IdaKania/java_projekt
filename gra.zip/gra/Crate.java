package gra;

public class Crate extends Item {
    public Crate() {
        name = "Skrzynia";
        rarity = "pospolity";
        desc = "Skrzynka, ktora najczeciej skrywa cos ciekawego, lecz nie zawsze. Potrzebny jest klucz, aby moc ja otworzyc"; // 33.3% legendarny, 33.3% rzadki, 33.3% pospolity
        accuracy = 0;
        damage = 0;
        points = 1;
    }
}
