package gra;

public class Rock extends Item {
    public Rock() {
        name = "Kamien";
        rarity = "pospolity";
        desc = "Odstrasza przed leszami";
        accuracy = 35;
        damage = 10;
        points = 1;
    }
}