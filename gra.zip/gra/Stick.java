package gra;

public class Stick extends Item {
    public Stick() {
        name = "Patyk";
        rarity = "pospolity";
        desc = "Chroni przed wrozkami";
        accuracy = 15;
        damage = 5;
        points = 1;
    }
}
