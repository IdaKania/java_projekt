package gra;

public class Raspberries extends Item {
    public Raspberries() {
        name = "Maliny";
        rarity = "pospolity";
        desc = "Moze przydadza Ci (badz komus) sie w godzinach glodu";
        accuracy = 0;
        damage = 0;
        points = 1;
    }
}