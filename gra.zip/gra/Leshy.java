package gra;

public class Leshy extends NPC {
    public Leshy() {
        name = "Leszy";
        attack = 26;
    }
}
