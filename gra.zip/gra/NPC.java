package gra;

public class NPC {
    public String name;
    public int attack;

    public NPC(String name, int attack) {
        this.name = name;
        this.attack = attack;
    }

    public NPC() {
    }
}
