package gra;

public class Item {
    public String name;
    public String rarity; //pospolity, rzadki, legendarny
    public String desc;
    public int accuracy;
    public int damage;
    public static int points;

    public Item(String name, String rarity, String desc, int accuracy, int damage, int points) {
        this.name = name;
        this.rarity = rarity;
        this.desc = desc;
        this.accuracy = accuracy;
        this.damage = damage;
        this.points = points;
    }

    public Item() {
    }

    public String getName() {
        return name;
    }

    public String getRarity() {
        return rarity;
    }

    public String getDesc() {
        return desc;
    }

    public int getAccuracy() {
        return accuracy;
    }

    public int getDamage() {
        return damage;
    }

    public int getPoints() {
        return points;
    }
}


