package gra;

public class Scissors extends Item {
    public Scissors() {
        name = "Nozyczki";
        rarity = "pospolity";
        desc = "Zwykle nozyczki";
        accuracy = 40;
        damage = 7;
        points = 1;
    }
}
