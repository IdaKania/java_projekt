package gra;

import java.util.Scanner;
import java.util.Random;

public class Main {
    public static Equipment e = new Equipment();
    public static Fairy fairy = new Fairy();
    public static Werewolf werewolf = new Werewolf();
    public static Leshy leshy = new Leshy();
    public static Troll troll = new Troll();
    public static Nexo nexo = new Nexo();
    public static MainCharacter character = new MainCharacter();
    public static Scanner scan = new Scanner(System.in);
    public static Random rand = new Random();

    public static final String BLUE = "\u001B[34m";
    public static final String GREEN = "\u001B[32m";
    public static final String RED = "\u001B[31m";
    public static final String PURPLE = "\u001B[35m";
    public static final String YELLOW = "\u001B[33m";
    public static final String CYAN = "\u001B[36m";
    public static final String RESET = "\u001B[0m";

    public static String idItem = "";
    public static String s_choice = "word";
    public static char choice;
    public static int has = 100;
    public static int rand_choice;
    public static int damage = 0;
    public static int damagePoints = 0;
    public static boolean gnomeHelp = false;
    public static boolean kittyDeath = false;

    public static void main(String[] args) throws InterruptedException{
          information();
          createCharacter();
          str1();
          str2();
          str3();
          str4();
          str5();
          str6();
          relax();
          str8();
          randomSpecialPage();
          str10();
          str11();
          randomSpecialPage();
          str13();
          str14();
          randomSpecialPage();
          relax();
          str17();
          str18();
          randomSpecialPage();
          str20();
          str21();
          str22();
          str23();
          str24();
          randomSpecialPage();
          str26();
          str27();
          randomSpecialPage();
          str29();
          str30();
          str31();
          str32();
          str33();
          str34();
          str35();
          str36();
          str37();
          str38();
          str39();
          hospitalPage();
          relax();
          str42();
          str43();
          str44();
          str45();
          str46();
          str47();
          str48();
          str49();
          str50();
          endGame();
    }

    public static void information() throws InterruptedException {
        System.out.println(BLUE + "Witaj w grze RPG!" + RESET);
        Thread.sleep(500);
        System.out.println("Twoim celem jest wydostanie sie z magicznego lasu.");
        Thread.sleep(1500);
        System.out.println("Dostajesz punkty za itemy, zadane obrazenia oraz strony, ktore sa pokazywane pod koniec gry.");
        Thread.sleep(2700);
        System.out.println("Aby wybrac akcje, musisz wpisac odpowiednia litere odpowiedzi.");
        Thread.sleep(2200);
        System.out.println("Powodzenia!\n");
        Thread.sleep(1000);
    }

    public static void str1() {
        page();
        System.out.println("Budzisz sie w lesie obok tajemniczego drzewa, ktorego korona jest niebieska oraz niebywale swiecaca.");
        System.out.println("Jedyne co masz przy sobie, to kawalek szkla.");
        e.Items_array.add(new Glass());
        character.itemPoints += Glass.points;
        System.out.println("Korona drzewa oswietla ci 3 drogi.");
        breaks();
        System.out.println("W ktora strone pojdziesz?");
        System.out.println("a) lewo");
        System.out.println("b) prosto");
        System.out.println("c) prawo");
        answer3();
    }

    public static void str2() throws InterruptedException {
        page();
        switch (choice) {
            case 'a' -> {
                System.out.println("Wybrales pojscie w lewo!");
                System.out.println("Wpadles do dziury.");
                System.out.println("Dostajesz male obrazenia");
                attack(3);
            }
            case 'b' -> {
                System.out.println("Wybrales pojscie prosto!");
                System.out.println("Widzisz skrzynke, ktora ze soba zabierasz");
                e.Items_array.add(new Crate());
                character.itemPoints += Crate.points;
            }
            case 'c' -> {
                System.out.println("Wybrales pojdzie w prawo!");
                System.out.println("Podnosisz duzy blekitny kamyk.");
                e.Items_array.add(new Rock());
                character.itemPoints += Rock.points;
            }
        }
        System.out.println("Spotykasz skrzata, ktory prosi o pomoc.");
        System.out.println("Wyglada na lekko zaniedbanego.");
        breaks();
        System.out.println("Czy chcesz go wysluchac?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str3() {
        page();
        if(choice=='a') {
            System.out.println("Prosi Cie, abys z nim poszedl w jedno miejsce");
            System.out.println("Czy zgadzasz sie, aby pojsc w to miejsce?");
            System.out.println("Skrzat patrzy na Ciebie lekko usmiechniety.");
        }
        else if(choice=='b') {
            System.out.println("Mowisz, ze nie masz zamiaru tracic czasu, poniewaz masz wazniejsze sprawy");
            System.out.println("Okazuje lekki smutek, ktora probuje ukrywac.");
            System.out.println("Skrzat dalej nalega. Pyta sie, czy pojdziesz z nim w jedno miejsce.");
        }
        breaks();
        System.out.println("Co mu odpowiesz?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str4() {
        page();
        if(choice == 'a'){
            gnomeHelp = true;
            System.out.println("Przestraszony skrzat prosi abys wsluchal sie w dzwieki.");
            System.out.println("'Te hic cepimus, te cepimus'.");
            System.out.println("Slychac je co chwile z roznych stron");
        }
        else if(choice == 'b') {
            System.out.println("Odchodzisz.");
            System.out.println("Po drodze slyszysz glosy, ktore slychac co chwile z roznych stron.");
            System.out.println("'Te hic cepimus, te cepimus'.");
        }
        breaks();
        System.out.println("Czy idziesz sprawdzic co to?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str5() {
        page();
        if(choice=='a') {
            System.out.println("Szukasz skad dokladnie dochodza dzwieki.");
        }
        else if(choice=='b') {
            System.out.println("Olewasz to i idziesz dalej.");
        }
        System.out.println("Idziesz w jedna strone, lecz dzwieki ucichaja.");
        System.out.println("Kiedy idziesz w druga, sytuacje sie powtarza.");
        breaks();
        System.out.println("Czy zamierzasz isc dalej czy odpuscic?");
        System.out.println("a) Idz");
        System.out.println("b) Odpusc");
        answer2();
    }

    public static void str6() throws InterruptedException {
        page();
        if(choice=='a'){
            System.out.println("Skupiasz sie chwile.");
            dots();
        }
        else if(choice=='b'){
            System.out.println("Odchodzisz, jednak nie wiesz w jaka strone skrecic.");
            System.out.println("Muzyka staje sie coraz glosniejsza.");
        }
        System.out.println("Zza twoich plecow wylania sie golem.");
        System.out.println("(Golemy są niewolnikami swoich twórców i są bezmyślnie posłuszni).");
        System.out.println("Szepcze Ci tylko 'vade, non reverteris'.");
        System.out.println("Nie rozumiesz co to znaczy, jednak niedaleko Ciebie jest skrzat, ktorego spotkales wczesniej.");
        System.out.println("Tlumaczy Ci, ze golem powiedzial, zebys juz tu sie nigdy nie pokazywal.");
        System.out.println("Idziesz dalej");
        breaks();
        System.out.println("W ktora strone skrecisz?");
        System.out.println("a) Prawo");
        System.out.println("b) Lewo");
        answer2();
    }

    public static void str8() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Spotkales wioske, w ktora jest dalej jest na terenie z golemami");
            System.out.println("Podchodzi do Ciebi kolejny golem, ktory denerwuje i podchodzi do Ciebie.");
            attack(10);
        }
        else if(choice=='b') {
            System.out.println("Widzisz przed soba swiecaca sie szyszke, ktora podnosisz.");
            e.Items_array.add(new Cone());
            character.itemPoints += Cone.points;
        }
        System.out.println("Powoli robi sie ciemno.");
        System.out.println("Widzisz jak przebiega przed Toba kot.");
        System.out.println("Starasz sie znalezc miejsce do spania.");
        System.out.println("Widzisz wiekszy szalas");
        breaks();
        System.out.println("Czy zamierzasz isc w jego strone?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str10() {
        page();
        if(choice=='a') {
            System.out.println("Na wejsciu lezy mlotek.");
            System.out.println("Postanawiasz go wziac.");
            e.Items_array.add(new Hammer());
            character.itemPoints += Hammer.points;
            System.out.println("Szalas, do ktorego wszedles wydaje sie zlym miejscem do spania, wiec szukasz dalej.");
        }
        else if(choice=='b') {
            System.out.println("Szukasz innego miejsca do spania.");
        }
        System.out.println("Czujesz sie coraz bardziej glodny.");
        System.out.println("Widzisz z daleka krzak z malinami.");
        breaks();
        System.out.println("Czy chcesz je sprobowac?");
        System.out.println("a) Sprobuj");
        System.out.println("b) Nie probuj");
        answer2();
    }

    public static void str11() throws InterruptedException {
        page();
        if(choice=='a') {
            int randomNum = rand.nextInt(2);
            if(randomNum==0) {
                System.out.println("Maliny okazaly sie pokryte dziwnym kwasem.");
                attack(20);
            }
            else {
                System.out.println("Maliny okazaly sie byc dobre.");
                System.out.println("Dzieki zjedzeniu ich masz wiecej sily.");
                System.out.println("Bierzesz pare ze soba.");
                e.Items_array.add(new Raspberries());
                character.itemPoints += Raspberries.points;
            }
        }
        else if(choice=='b') {
            System.out.println("Jestes glodny i zmeczony");
        }
        System.out.println("Czy chcesz dalej szukac miejsca do spania?");
        breaks();
        System.out.println("a) tak");
        System.out.println("b) nie");
        answer2();
    }

    public static void str13() {
        page();
        if(choice=='a') {
            System.out.println("W obszarze, w jakim jestes nie mozesz nic znalezc.");
            System.out.println("Poddales sie z szukaniem miejsca do spania.");
        }
        else if(choice=='b') {
            System.out.println("Zrezygnowales z szukania miejsca do spania.");
        }
        breaks();
        System.out.println("Co zamierzasz zrobic?");
        System.out.println("a) Idz spac na trawie");
        System.out.println("b) Nie idz spac");
        answer2();
    }

    public static void str14() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Idziesz spac na trawie.");
            dots();
            System.out.println("Rano budzisz sie i czujesz bol.");
            System.out.println("Zostales pogryziony przez dzisie mrowki.");
        }
        else if(choice=='b') {
            System.out.println("Coraz gorzej sie czujesz.");
            System.out.println("Powoli zamykaja sie oczy, jednak nie dajesz za wygrana.");
            System.out.println("Pomimo tego Twoje zdrowie spada.");
        }
        damage=10;
        attack(damage);
        System.out.println("Nie czujesz sie najlepiej");
        breaks();
        System.out.println("Co zamierzasz zrobic?");
        System.out.println("a) Isc przed siebie");
        System.out.println("b) Szukac dalej miejsca do spania");
        answer2();
    }

    public static void str17() {
        page();
        if(choice=='a') {
            System.out.println("Idziesz dalej.");
        }
        else if(choice=='b') {
            System.out.println("Niestety nie znalazles nowego miejsca do spania");
        }
        System.out.println("Idac przed las spotykasz skrzata, ktory utknal w dziurze.");
        breaks();
        System.out.println("Czy postanawiasz mu pomoc?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str18() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Ciagniesz skrzata za nogi.");
            System.out.println("Kiedy juz pomogles mu wyjsc okazuje sie, ze nie jest to skrzat sprzed poczatku Twojej wyprawy tylko inny.");
            System.out.println("Dodatkowo skrzat okazuje sie miec wscieklizne.");
            System.out.println("Zbiera Twoje wszystkie maliny i szklo sprzed momentu, z ktorym sie obudziles w lesie.");
            attack(15);
            deleteItemFromEq("Maliny");
            deleteItemFromEq("Szklo");
            e.printEq();
        }
        if(choice=='b') {
            System.out.println("Idziesz dalej.");
        }
        System.out.println("Wpadasz do dziury.");
        breaks();
        System.out.println("Czy zamierzasz w niej spac?");
        System.out.println("a) tak");
        System.out.println("b) nie");
        answer2();
    }

    public static void str20() {
        page();
        if(choice=='a') {
            System.out.println("Robi sie powoli jasno.");
            System.out.println("Lecz pomimo tego jest zimno.");
            System.out.println("Rozgladasz sie po dziurze i widzisz drzwiczki do jakiegos schronu.");
            System.out.println("Znajdujesz klucz!");
            e.Items_array.add(new Key());
            character.itemPoints += Key.points;
            if (check("Skrzynia")) {
                System.out.println("Mozesz otworzyc skrzynke posiadajac klucz!");
                crateOpen();
                deleteItemFromEq("Klucz");
                deleteItemFromEq("Skrzynia");
                character.itemPoints -= Key.points;
                character.itemPoints -= Crate.points;
            }
            else {
                System.out.println("Niestety, nie masz skrzynki, wiec nie mozesz uzyc klucza");
            }
            System.out.println("Probujesz sie ocieplic");
            System.out.println("W schornie byl lysy kot i sie do ciebie tuli");
        }
        else if(choice=='b') {
            System.out.println("Wydostajesz sie i biegniesz do wczesniejszego szalasu, aby sie ocieplic.");
            System.out.println("W szalasie byl lysy kot i sie do ciebie tuli");
        }
        breaks();
        System.out.println("Jak zareagujesz?");
        System.out.println("a) odepchnij go");
        System.out.println("b) poglaszcz go");
        System.out.println("c) zacznij do niego mowic jak do czlowieka");
        answer3();
    }

    public static void str21() {
        page();
        if(choice=='a') {
            System.out.println("Odpychasz kota.");
            System.out.println("Jednak ten znow do Ciebie podchodzi.");
        }
        else if(choice=='b') {
            System.out.println("Glaszczesz kota.");
            System.out.println("Wyglada na zadowolonego.");
        }
        else if(choice=='c') {
            System.out.println("Zaczynasz do niego mowic jak do czlowieka.");
            System.out.println("Masz nadzieje, ze jest on czarodziejskim kotem, ktory Cie zrozumie.");
            System.out.println("Lecz nic ci nie odpowiada i wyglada na jednak zwyklego kota.");
        }
        System.out.println("Dalej przeszukujesz schron zanim pojdziesz spac.");
        breaks();
        System.out.println("Co chcesz sprawdzic?.");
        System.out.println("a) Co jest pod lozkiem");
        System.out.println("b) Gore szafy");
        answer2();
    }

    public static void str22() {
        page();
        if(choice=='a') {
            System.out.println("Znajdujesz fragment lisciku.");
            System.out.println("'Zsylaj nam wiecej dobra,'");
            System.out.println("'Kolo drzewa nadziei.'");
            System.out.println("'Oby istoty sie nie dowiedzialy, ze jest dla nich szansa'");
            System.out.println("W tym momencie dowiedziales sie, ze mozesz wyjsc z tego lasu dzieki temu drzewu");
            System.out.println("Szukasz dalej informacji o tym drzewie.");
        }
        else if(choice=='b') {
            System.out.println("Znajdujesz ksiazke.");
            System.out.println("Okazuje sie byc o drzewie, przy ktorym sie obudziles.");
            System.out.println("'Drzewo nadziei:'");
            System.out.println("'Drzewo o niebieskiej koronie, ktore jest sercem lasu.'");
            System.out.println("'Jego magia dziala po zachodzie slonca.'");
        }
        System.out.println("Jutro zamierzasz isc na podroz.");
        System.out.println("Teraz jestes wyczerpany.");
        breaks();
        System.out.println("Czy idziesz sie polozyc spac?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str23() {
        page();
        if(choice=='a') {
            System.out.println("Idziesz polozyc sie na lozko.");
        }
        else if(choice=='b') {
            System.out.println("Przez kolejne 15 minut probujesz znalezc wiecej informacji o drzewie nadziei.");
            System.out.println("Nie masz sily dalej szukac.");
            System.out.println("Rzucasz sie na lozko.");
        }
        System.out.println("Po dlugiej nocy budza cie promienie sloneczne.");
        breaks();
        System.out.println("Czy chcesz zaslonic rolety czy jeszcze polezec i popatrzec za okno?");
        System.out.println("a) Zaslon");
        System.out.println("b) Nie zaslaniaj");
        answer2();
    }

    public static void str24() {
        page();
        if(choice=='a') {
            System.out.println("Kot zaczyna miauczec, aby zwrocic Ci uwage na rolety");
            System.out.println("Zaslaniasz okno.");
        }
        else if(choice=='b') {
            System.out.println("Nie zaslaniasz rolet.");
            System.out.println("Jednak kot, ktory tam z Toba zostal probuje zwrocic Twoja uwage na rolety.");
            System.out.println("Ciagle miauczy.");
            System.out.println("Ostatecznie zaslaniasz okno, zeby przestal.");
        }
        System.out.println("Promienie sloneczne lekko przewsituja przez rolety.");
        System.out.println("Widzisz tam dwie nowe sciezki, ktorych wczesniej nie bylo.");
        System.out.println("Wybiegasz z domku.");
        breaks();
        System.out.println("Czy zamierzasz zabrac kota ze soba?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str26() {
        page();
        if(choice=='a') {
            System.out.println("Zabrales kota ze soba.");
        }
        else if(choice=='b') {
            System.out.println("Kot wybiegl za Toba.");
        }
        System.out.println("Widzisz dwie drogi.");
        System.out.println("Nie wiesz ktora prowadzi do drzewa nadziei.");
        breaks();
        System.out.println("Ktora droga idziesz?");
        System.out.println("a) Droga po lewej");
        System.out.println("b) Droga po prawej");
        answer2();
    }

    public static void str27() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Zostales zaatakowany przez dzika");
            attack(15);
        }
        else if(choice=='b') {
            System.out.println("Widzisz zrodelko wody.");
            System.out.println("Postanawiasz sie z niego napic.");
            getHP(20);
        }
        breaks();
        System.out.println("Czy zamierzasz isc dalej czy zawrocic?");
        System.out.println("a) Idz dalej");
        System.out.println("b) Zawroc");
        answer2();
    }

    public static void str29() {
        page();
        if(choice=='a') {
            System.out.println("Idziesz dalej.");
        }
        else if(choice=='b') {
            System.out.println("Droga za toba znika.");
            System.out.println("Postanawiasz isc dalej.");
        }
        System.out.println("Widzisz maliny.");
        breaks();
        System.out.println("Czy zamierzasz je zjesc?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str30() {
        page();
        if(choice=='a') {
            System.out.println("Maliny okazaly sie byc dobre.");
            getHP(20);
            System.out.println("Bierzesz ich troche ze soba");
            if(!check("Maliny")) {
                e.Items_array.add(new Raspberries());
                character.itemPoints += Raspberries.points;
            }
        }
        else if(choice=='b') {
            System.out.println("Omijasz krzak z malinami i idziesz dalej.");
        }
        System.out.println("Zaczyna sie trzesc ziemia.");
        System.out.println("Z sekundy na sekunde jest to coraz silniejsze.");
        breaks();
        System.out.println("Czy idziesz dalej czy zostajesz?");
        System.out.println("a) Dalej");
        System.out.println("b) Zostaje");
        answer2();
    }

    public static void str31() {
        page();
        if(choice=='a') {
            System.out.println("Podchodzisz coraz blizej.");
        }
        else if(choice=='b') {
            System.out.println("Usiadles na pniu.");
        }
        System.out.println("Zauwazasz ogromna postac w oddali.");
        System.out.println("Postanawiasz sie oddalic.");
        System.out.println("Jednak od razu za Toba jest tak samo wygladajaca postac, jaka widziales z drugiej strony.");
        breaks();
        System.out.println("Czy postanawiasz pierwszy walnac?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str32() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Probujesz walnac nieznana ci postac, jednak nie udaje Ci sie to.");
        }
        else if(choice=='b') {
            System.out.println("Czekasz aby sprawdzic, czy postac chce sie zaatakowac.");
        }
        System.out.println("ROZPOCZYNA SIE WALKA");
        System.out.println("Postac atakuje Cie");
        attack(10);
        breaks();
        System.out.println("Czy zamierzasz dalej walczyc?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str33() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Walczysz dalej.");
        }
        else if(choice=='b') {
            System.out.println("Probujesz uciec, ale na marne.");
        }
            if(check("Mlotek")) {
                System.out.println("Na szczescie masz mlotek!");
                System.out.println("Walisz nim w glowe postaci.");
                System.out.println("Jest lekko oszolomiony.");
            }
            else {
                System.out.println("Probujesz zaatakowac.");
                System.out.println("Lecz postac unika Twojego ataku.");
                attack(20);
            }
        breaks();
        System.out.println("Jak zamierzasz zaatakowac postac?");
        System.out.println("a) Uderzyc piescia");
        System.out.println("b) Kopnac");
        answer2();
    }

    public static void str34() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Postanowiles uderzyc piescia.");
            System.out.println("Postac unika twojego ataku");
            attack(10);
        }
        else if(choice=='b') {
            System.out.println("Postanowiles kopnac.");
            System.out.println("Okazal sie to dobry wybor.");
            System.out.println("Jest to czuly punkt postaci.");
        }
        System.out.println("Kiedy zamierzasz dalej walczyc slyszysz ryk zwierzecia za Toba.");
        System.out.println("Myslisz o tym, ze zaraz zginiesz.");
        System.out.println("Odwracasz sie.");
        System.out.println("Wyglada jakby zwierze bieglo w Twoja strone.");
        System.out.println("Jednak okazuje sie, ze to kot, ktorego spotkales, ktory przemienil sie w inne dzikie zwierze.");
        breaks();
        System.out.println("Zamierzasz mu pomoc czy zostac i patrzec?");
        System.out.println("a) Pomoz");
        System.out.println("b) Patrz");
        answer2();
    }

    public static void str35() {
        page();
        if(choice=='a') {
            System.out.println("Postanowiles pomoc.");
            System.out.println("Jednak kot krzyczy, zebys zostal tam.");
        }
        else if(choice=='b') {
            System.out.println("Postanowiles poczekac.");
            System.out.println("Kot widzi, ze postac kieruje atak ku Tobie.");
            System.out.println("Krzyczy, zebys uwazal.");
        }
        System.out.println("Okazalo sie, ze rzeczywiscie Cie rozumie i potrafi mowic.");
        breaks();
        System.out.println("Co zamierzasz mu odpowiedziec?");
        System.out.println("a) 'Ty umiesz mowic?'");
        System.out.println("b) 'Dasz rade!'");
        System.out.println("c) Nic nie mow");
        answer3();
    }

    public static void str36() {
        page();
        if(choice=='a') {
            System.out.println("Pytasz sie go czy umie mowic.");
            System.out.println("Jednak kot Ci nie odpowiada, bo jest zbyt zajety walka.");
        }
        else if(choice=='b') {
            System.out.println("Krzyczysz, ze da rade.");
        }
        else if(choice=='c') {
            System.out.println("Nic nie mowisz, jestes zbyt oszolomiony tym.");
        }
        System.out.println("Kotu udaje sie pokonac przeciwnika");
        System.out.println("Podchodzi zmeczony i zmienia sie ponownie w zwyklego kota.");
        breaks();
        System.out.println("Jak zamierzasz zareagowac?");
        System.out.println("a) 'Kim jestes?'");
        System.out.println("b) 'Dziekuje'");
        System.out.println("c) 'Dalbym sam rade'");
        answer3();
    }

    public static void str37() {
        page();
        if(choice=='a') {
            System.out.println("'Mieszkam tu od wielu lat'.");
            System.out.println("'Moze nie wygladam, ale jestem straznikiem ludzi, ktorzy zostali tu zeslani'.");
        }
        else if(choice=='b') {
            System.out.println("'W zasadzie, to mi nie dziekuj'.");
            System.out.println("'To moje zajecie, czuje sie odpowiedzialny za Ciebie'.");
        }
        else if(choice=='c') {
            System.out.println("'Widzialem jak jestes na skraju wyczerpania'.");
            System.out.println("'Nie dalbys sobie rady sam'.");
        }
        System.out.println("'Mialem Cie na oku od samego poczatku i jestem tu, aby Cie chronic'.");
        System.out.println("Kot opowiada Ci o calej sytuacji.");
        breaks();
        System.out.println("Jak mu odpowiesz?");
        System.out.println("a) 'Czyli jestes straznikiem, ktory broni ludzi w tym lesie?'");
        System.out.println("b) 'Nie do wiary! Gadajacy kot!'");
        System.out.println("c) 'Tak czy inaczej - radze sobie od poczatku, nawet, kiedy Cie nie bylo'");
        answer3();
    }

    public static void str38() {
        page();
        if(choice=='a') {
            System.out.println("'Dokladnie tak'.");
        }
        else if(choice=='b') {
            System.out.println("'To tylko moje przebranie'.");
            System.out.println("'Nie dziw sie az tak'.");
            System.out.println("'Przeciez koty nie gadaja'.");
        }
        else if(choice=='c') {
            System.out.println("'Jasne, gdyby to tylko jeszcze byla prawda'.");
            System.out.println("'Od poczatku pomagam Ci w taki sposob, ze tego nie widzisz'.");
            System.out.println("'Zostalbys inaczej juz tu zjedzony w ciagu jednego dnia'.");
        }
        System.out.println("'Tak wiec'.");
        System.out.println("'Moim celem jest Cie teraz zaprowadzenie do drzewa nadziei'.");
        breaks();
        System.out.println("Czy chcesz isc za kotem?");
        System.out.println("a) Tak");
        System.out.println("b) Nie");
        answer2();
    }

    public static void str39() {
        page();
        if(choice=='a') {
            System.out.println("'Czeka nas w zasadzie krotka droga'.");
            System.out.println("'Istotniejszym problemem jest, czy uda Ci sie stad wyjsc'.");
            System.out.println("'Na miejscu moze czekac duzo groznych stworow'.");
        }
        else if(choice=='b') {
            System.out.println("'Jestes idiota jesli serio nie chcesz przezyc, chodz za mna'.");
            System.out.println("Po tych slowach idziesz za kotem.");
        }
        breaks();
        System.out.println("Co mu odpowiesz?");
        System.out.println("a) 'Na pewno sobie poradzimy'");
        System.out.println("b) 'Nie ma szans, ze nam sie uda'");
        answer2();
    }

    public static void str42() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("'Dobrze, ze jestes pozytywnie nastawiony'.");
            System.out.println("'Takie nastawienie na pewno sie przyda'.");
        }
        else if(choice=='b') {
            System.out.println("'Pesymisci nigdy nie wygraja'.");
            System.out.println("'Pamietaj'.");
        }
        dots();
        System.out.println("Po 15 minutach drogi widzicie drzewo");
        System.out.println("'UWAZAJ'.");
        System.out.println("'O nie! Trafilismy na Nexo'.");
        System.out.println("'Krol, ktory rzadza tym lasem'.");
        System.out.println("'PODCHODZI TU'.");
        breaks();
        System.out.println("Co zamierzasz zrobic");
        System.out.println("a) Atak");
        System.out.println("b) Ucieknij dalej");
        answer2();
    }

    public static void str43() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Zaczynasz pierwszy atakowac");
        }
        else if(choice=='b') {
            System.out.println("Nexo zaatakowal Twojego stroza.");
            System.out.println("Stroz wywraca sie metr dalej.");
        }
        System.out.println("'To nie bedzie latwe, musimy wspolpracowac'.");
        while(nexo.HP>=55) {
            bossFight();
        }
        e.Items_array.remove(has);
        e.printEq();
        System.out.println("O nie! Twoja bron sie zepsula!");
        breaks();
        System.out.println("Co zamierzasz zrobic");
        System.out.println("a) Atak");
        System.out.println("b) Ucieknij dalej");
        answer2();
    }

    public static void str44() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Twoj atak okazal sie celny.");
        }
        else if(choice=='b') {
            System.out.println("Nexo Cie atakuje");
            attack(10);
        }
        System.out.println("'Wiem czym mozemy go zabic!'.");
        System.out.println("'Legendarny, albo rzadki item sie przyda'.");
        breaks();
        System.out.println("a) Sprawdz, czy masz legendarne albo rzadki itemy w ekwipunku");
        System.out.println("b) Olej to i zacznij atakowac");
        answer2();
    }

    public static void str45() throws InterruptedException {
        page();
        if(choice=='a') {
            if(inEqRarity("legendarny")) {
                System.out.println("'Wow! Ty serio masz legendarna bron!'");
            }
            else if(inEqRarity("rzadki")) {
                System.out.println("'Masz rzadka bron, no niezle'");
            }
            else {
                System.out.println("Niestety nie masz zadnej legendarnej ani rzadkiej broni");
            }
        }
        else if(choice=='b') {
            System.out.println("Zaatakowales, niestety niecelnie");
            attack(10);
        }
        System.out.println("'Obawiam sie najgorszego'.");
        System.out.println("'Widzisz go teraz?'.");
        System.out.println("'Zaczal swiecic sie na niebiesko'.");
        System.out.println("'W jego przypadku oznacza to, ze zadaje 5 razy mocniejsze obrazenia'.");
        System.out.println("'Jest szansa, ze nie przezyjemy'.");
        breaks();
        System.out.println("Co zamierzasz zrobic?");
        System.out.println("a) Atak");
        System.out.println("b) Ucieknij dalej");
        answer2();
    }

    public static void str46() {
        page();
        if(choice=='a') {
            if(inEqRarity("legendarny") || inEqRarity("rzadki")) {
                System.out.println("'SUPER, POKONALES ICH'");
            }
            else {
                System.out.println("Wiedziales, ze byla to ostatnia szasna.");
                System.out.println("Zaatakowales, trafiles idealnie w czuly punkt.");
                System.out.println("Krol umarl");
                System.out.println("Wygrywasz walke.");
            }
            System.out.println("Stroz mdleje.");
        }
        else if(choice=='b') {
            System.out.println("Uciekles, stroz widzi, ze nie dalibyscie rady.");
            System.out.println("Odpala stan samodestrukcji.");
            System.out.println("Stroz oraz krolowie umieraja.");
            System.out.println("Przezyles tylko ty.");
            kittyDeath = true;
        }
        breaks();
        System.out.println("Jak reagujesz");
        System.out.println("a) Podbiegnij do niego");
        System.out.println("b) Olej go");
        answer2();
    }

    public static void str47() throws InterruptedException {
        page();
        if(choice=='a') {
            if (!kittyDeath) {
                System.out.println("'Strozu, wszystko dobrze?'.");
                System.out.println("'Strozu!'.");
                System.out.println("Stroz otwiera oczy, powoli wstaje i zaczyna mowic.");
                System.out.println("'Super sobie poradziles'.");
                System.out.println("'Lecz musimy sie powoli zegnac " + character.name + "'.");
                System.out.println("'Wystarczy, ze wejdziesz na korone drzewa i przeniesiesz sie do swojego swiata'.");
                System.out.println("'Byles moim ostatnim podopiecznym'.");
                System.out.println("'Ty wrocisz do domu, a mnie juz tylko czeka spokojna smierc'.");
                System.out.println("'Bardzo milo mi bylo z Toba wspolpracowac'.");
            }
            else {
                System.out.println("I po co ucieklem...");
                System.out.println("Moze i przezylem, ale jakim kosztem");
                System.out.println("Przepraszam...");
            }
        }
        else if(choice=='b') {
            if(!kittyDeath) {
                System.out.println("Odchodzisz bez slowa i bez ostatniego spojrzenia");
            }
            else {
                System.out.println("Nie musial mi pomagac.");
                System.out.println("To tylko jego wina.");
            }
        }
        System.out.println("Jestes juz na koronie drzewa");
        dots();
        System.out.println("'Do widzenia'.");
        System.out.println("Odwracasz sie.");
        System.out.println("Widzisz malego skrzata, ktorego spotkales na poczatku gry.");
        if(gnomeHelp) {
            System.out.println("Dziekuje za pomoc, jestes dobrym czlowiekiem");
        }
        else {
            System.out.println("Moze i mi nie pomogles, ale jestem pewny, ze jestes dobrym czlowiekiem");
        }
        breaks();
        System.out.println("Jak reagujesz");
        System.out.println("a) Podziekuj");
        System.out.println("b) Odejdz");
        answer2();
    }

    public static void str48() throws InterruptedException {
        page();
        if(choice=='a') {
            System.out.println("Dziekuje.");
        }
        else if(choice=='b') {
            dots();
        }
        System.out.println("Wchodzisz do korony drzewa.");
        System.out.println("Widzisz juz swoj swiat");
        System.out.println("Wychodzisz na pustyni");
        breaks();
        System.out.println("Co robisz?");
        System.out.println("a) Rozejrzyj sie");
        System.out.println("b) Idz przed siebie");
        answer2();
    }

    public static void str49() {
        page();
        if(choice=='a') {
            System.out.println("Patrzysz w gore");
        }
        else if(choice=='b') {
            System.out.println("Idziesz przed siebie");
        }
        System.out.println("Widzisz cos");
        breaks();
        System.out.println("Co robisz?");
        System.out.println("a) Zmruz oczy");
        System.out.println("b) Nie zmruzaj oczu");
        answer2();
    }

    public static void str50() {
        page();
        if(choice=='a') {
            System.out.println("Widzisz na niebie napis.");

        }
        else if(choice=='b') {
            System.out.println("Spojrzales pod nogi.");
            System.out.println("Widzisz napis na piasku.");
        }
        System.out.println("'Jestem przy Tobie'.");
        breaks();
        System.out.println("Jak reagujesz");
        System.out.println("a) Odwroc wzrok");
        System.out.println("b) Usmiechnij sie");
        answer2();
    }

    public static void breaks() {
        System.out.println(PURPLE + "--------------" + RESET);
    }

    public static void dots() throws InterruptedException {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                System.out.print(".");
                Thread.sleep(300);
            }
            System.out.println();
        }
    }

    public static void attack(int damage2) throws InterruptedException {
        System.out.println(RED + "Otrzymujesz " + damage2 + " obrazen" + RESET);
        character.HP -= damage2;
        HP();
    }

    public static void getHP(int health) {
        System.out.println(GREEN + "Otrzymujesz dodatkowe " + health + "HP" + RESET);
        character.HP += health;
        System.out.println("Posiadasz jeszcze " + character.HP + "HP");
    }

    public static void endGame() throws InterruptedException {
        breaks();
        System.out.println(GREEN + "Ukonczyles gre" + RESET);
        System.out.println("Mam nadzieje, ze sie podobalo!");
        endStats();
    }

    public static boolean inEqRarity(String thing){
        int has = 0;
        for(int a=0; a<e.Items_array.size(); a++) {
            if (e.Items_array.get(a).getRarity().equals(thing)) {
                has = 1;
                break;
            }
        }
        return has == 1;
    }

    public static void crateOpen() {
        int randomItemInCrate = rand.nextInt(3);
        switch (randomItemInCrate) {
            case 0 -> {
                System.out.println("Wylosowales pospolity item!");
                e.Items_array.add(new Leaf());
                character.itemPoints += Leaf.points;
            }
            case 1 -> {
                System.out.println("Wylosowales rzadki item!");
                e.Items_array.add(new Sword());
                character.itemPoints += Sword.points;
            }
            case 2 -> {
                System.out.println("Wylosowales legendarny item!");
                e.Items_array.add(new Wand());
                character.itemPoints += Wand.points;
            }
        }
    }

    public static void itemPage() {
        System.out.println(CYAN + "Po drodze spotykasz Hohelka - krasnala handlarza." + RESET);
        System.out.println("Oferuje ci w prezencie jeden z przedmiotow.");
        breaks();
        System.out.println("Co wybierasz?");
        System.out.println("a) Patyk");
        System.out.println("b) Noz");
        System.out.println("c) Nozyczki");
        answer3();
        if(choice == 'a') {
            e.Items_array.add(new Stick());
            character.itemPoints += Stick.points;
        }
        if(choice == 'b') {
            e.Items_array.add(new Knife());
            character.itemPoints += Knife.points;
        }
        if(choice == 'c') {
            e.Items_array.add(new Scissors());
            character.itemPoints += Scissors.points;
        }
        e.printEq();
    }

    public static void endGamePage() throws InterruptedException {
        System.out.println("W calym lesie slychac tajemnicza muzyke.");
        System.out.println("Plon smoczych centaurów obkraza caly las i wszystkich atakuje.");
        System.out.println("Niestety, nie zdazyles sie ukryc ani uciec.");
        System.out.println(RED + "Koniec gry." + RESET + "\n");
        endStats();
    }

    public static void createCharacter() {
        System.out.println("Zanim to - stworz swoja postac");
        System.out.println("Imie postaci: ");
        character.name = scan.nextLine();
        System.out.println();
        System.out.println("Czesc " + CYAN + character.name + RESET + "!");
        System.out.println("Twoja postac posiada: ");
        System.out.println(character.HP + " HP,");
        System.out.println(character.accuracy + "% celnosci\n");
    }

    public static void randomSpecialPage() throws InterruptedException {
        page();
        rand_choice = rand.nextInt(8);
        if(character.page<=10) {
            while(rand_choice==0) {
                rand_choice = rand.nextInt(4);
            }
        }
        switch (rand_choice) {
            case 0 -> endGamePage();
            case 1,2 -> itemPage();
            case 3,4 -> hospitalPage();
            case 5,6 -> enemyPage();
            case 7 -> easyWinPage();
        }
    }

    public static void page() {
        character.page += 1;
        System.out.println(BLUE + "STRONA " + character.page + "/50" + RESET);
    }

    public static void easyWinPage() throws InterruptedException {
        System.out.println("Zaczepia cie dwuogonowa wiewiorka, ktora prowadzi Cie w pewne miejsce.");
        System.out.println("Wiewiorka prowadzi Cie do niebieskiego tunelu.");
        System.out.println("Po 15 minutach przekroczyles prog lasu i wychodzisz w innym lesie, ktory rozpoznajesz");
        System.out.println(GREEN + "Wygrales" + RESET);
        endStats();
    }

    public static void hospitalPage() {
        System.out.println(CYAN + "Spotkales lesny szpital." + RESET);
        System.out.println("Znalazles w nim lekarstwo, ktory dodaje Ci 40HP");
        getHP(40);
    }

    public static void enemyPage() throws InterruptedException {
    rand_choice = rand.nextInt(4);
        switch (rand_choice) {
            case 0 -> {
                System.out.println("Widzisz domek na drzewie, do ktorego postanawiasz wejsc.");
                System.out.println("Zauwaza sie wrozka Polia.");
                if (check("Patyk")) {
                    System.out.println(GREEN + "Na szczescie w ekwipunku posiadasz czarodziejski patyk, ktory chroni Cie przed wrozkami" + RESET);
                } else {
                    attack(fairy.attack);
                }
            }
            case 1 -> {
                System.out.println("Jest ciemno, a w lesie zgromadzily sie wilki.");
                System.out.println("Spotykasz jednego z nich.");
                if (check("Noz")) {
                    System.out.println(GREEN + "Na szczescie w ekwipunku posiadasz noz, ktory chroni Cie przed wilkami" + RESET);
                } else {
                    attack(werewolf.attack);
                }
            }
            case 2 -> {
                System.out.println("Podczas gdy chodzisz po lesie szukajac drogi powrotnej, widzisz w oddali wysoka, szczupla postac.");
                System.out.println("Jest to leszy, ktory wygania cie ze swojego terenu.");
                if (check("Kamien")) {
                    System.out.println(GREEN + "Na szczescie w ekwipunku posiadasz kamien, ktory chroni Cie przed leszami" + RESET);
                } else {
                    attack(leshy.attack);
                }
            }
            case 3 -> {
                System.out.println("Slyszysz coraz glosniejszy krzyk blisko ciebie.");
                System.out.println("Podbiega do Ciebie Troll, który chce uderzyc sie z reki.");
                if (check("Szklo")) {
                    System.out.println(GREEN + "Na szczescie w ekwipunku posiadasz szklo, ktory chroni Cie przed trollami" + RESET);
                } else {
                    attack(troll.attack);
                }
            }
        }
        System.out.println();
    }

    public static boolean check(String thing) {
        int has = 0;
        for (int x=0; x<e.Items_array.size(); x++) {
            if (e.Items_array.get(x).getName().equals(thing)) {
                has = 1;
                break;
            }
        }
        return has == 1;
    }

    public static void deleteItemFromEq(String thing1) {
        for (int x=0; x<e.Items_array.size(); x++) {
            if(e.Items_array.get(x).getName().equals(thing1)) {
                character.itemPoints -= e.Items_array.get(x).points;
                e.Items_array.remove(x);
            }
        }
    }

    public static void relax() {
        page();
        System.out.println(CYAN + "Znalazles chwile czasu, aby usiasc i odpoczac." + RESET);
        System.out.println("Regenerujesz sie");
        getHP(20);
        System.out.println();
    }

    public static void HP() throws InterruptedException {
        if(character.HP>=0) {
            System.out.println(GREEN + "Posiadasz jeszcze " + character.HP + "HP." + RESET);
        }
        else {
            System.out.println(RED + "Dostales za duzo obrazen i umierasz.");
            System.out.println("THE END" + RESET);
            endStats();
        }
    }

    public static void answer2() {
        boolean go=false;
        while(!go) {
                s_choice = scan.nextLine();
                choice = s_choice.charAt(0);
            if((choice=='a' || choice=='b') && s_choice.length()==1) {
                go=true;
            }
            else {
                wrongAnswer();
            }
        }
        System.out.println();
    }

    public static void answer3() {
        boolean go=false;
        while(!go) {
            s_choice = scan.nextLine();
            choice = s_choice.charAt(0);
            if((choice=='a' || choice=='b' || choice=='c') && s_choice.length()==1){
                go=true;
            }
            else {
                wrongAnswer();
            }
        }
        System.out.println();
    }

    public static void wrongAnswer() {
        System.out.println();
        System.out.println(RED + "Wybrano zla odpowiedz");
        System.out.println("Nalezy wpisac litere odpowiedzi na przyklad 'a' lub 'b' ");
        System.out.println("Upewnij sie, ze nie napisano odpowiedzi z duzej litery" + RESET);
        System.out.println();
    }

    public static void bossFight() throws InterruptedException {
        boolean go = false;
        e.printEq();
        System.out.println("Wpisz nazwe czym chcesz zaatakowac\n");
        while(!go) {
            idItem = scan.nextLine();
            if(check(idItem)) {
                System.out.println("Wybrales " + idItem);
                go=true;
            }
            else {
                System.out.println("Nie masz takiego przedmiotu");
                System.out.println("(Pamietaj o wielkosci znakow)");
            }
        }
        int d = e.Items_array.get(checkItemInEq(idItem)).getDamage();
        int accuracy = rand.nextInt(101);
        dots();
        if(accuracy<=e.Items_array.get(checkItemInEq(idItem)).getAccuracy()) {
            System.out.println("Zadajesz Nexo " + d + " obrazen");
            nexo.HP -= d;
            damagePoints += d;
        }
        else {
            System.out.println("Chybiles!");
        }
        System.out.println("Nexo ma jeszcze " + nexo.HP + " zycia\n");
        accuracy = rand.nextInt(101);
        dots();
        if(nexo.accuracy<accuracy) {
            attack(nexo.attack);
        }
        else {
            System.out.println("Nexo chybil!");
        }
    }

    public static int checkItemInEq(String thing) {
        for (int x=0; x<e.Items_array.size(); x++) {
            if(e.Items_array.get(x).getName().equals(thing)) {
                has=x;
                break;
            }
        }
        return has;
    }

    public static void endStats() throws InterruptedException {
        System.out.println();
        System.out.println( YELLOW + "STATYSTYKI" + RESET);
        Thread.sleep(600);
        System.out.println("Ilosc ukonczonych stron: " + character.page);
        Thread.sleep(600);
        e.printEq();
        Thread.sleep(1000);
        int points = character.itemPoints + character.page + damagePoints;
        System.out.println("Ilosc punktow za przedmioty: " + character.itemPoints);
        Thread.sleep(600);
        System.out.println("Ilosc punktow za strony: " + character.page);
        Thread.sleep(600);
        System.out.println("Ilosc punktow za zadane obrazenia: " + damagePoints);
        Thread.sleep(600);
        System.out.println("Razem punktow: " + points);
        System.exit(0);
    }
}