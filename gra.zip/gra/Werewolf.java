package gra;

public class Werewolf extends NPC{
    public Werewolf() {
        name = "Wilk";
        attack = 25;
    }
}