package gra;

public class Sword extends Item{
    public Sword() {
        name = "Miecz";
        rarity = "rzadki";
        desc = "Pomoze w walce z bossem";
        accuracy = 70;
        damage = 25;
        points = 2;
    }
}
