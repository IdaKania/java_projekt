package gra;

public class Nexo extends NPC {
    public int accuracy;
    public int HP;
    public Nexo() {
        name = "Nexo";
        HP = 70;
        attack = 20;
        accuracy = 60;
    }
}
