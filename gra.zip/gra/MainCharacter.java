package gra;

public class MainCharacter {
    String name;
    int HP = 100;
    int accuracy = 70;
    int page = 0;
    int itemPoints = 0;
}
