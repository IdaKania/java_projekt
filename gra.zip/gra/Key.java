package gra;

public class Key extends Item {
    public Key() {
        name = "Klucz";
        rarity = "pospolity";
        desc = "Klucz do otworzenia skrzynki";
        accuracy = 5;
        damage = 2;
    }
}
