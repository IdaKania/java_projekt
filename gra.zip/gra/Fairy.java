package gra;

public class Fairy extends NPC {
    public Fairy() {
        name = "Wrozka";
        attack = 30;
    }
}
