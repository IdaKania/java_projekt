package gra;

public class Wand extends Item {
    public Wand() {
        name = "Rozdzka";
        rarity = "legendarny";
        desc = "Pomoze w walce z bossem";
        accuracy = 80;
        damage = 30;
        points = 3;
    }
}
