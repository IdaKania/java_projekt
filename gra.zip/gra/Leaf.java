package gra;

public class Leaf extends Item {
    public Leaf() {
        name = "Lisc";
        rarity = "pospolity";
        desc = "Zwykly lisc";
        accuracy = 5;
        damage = 1;
        points = 1;
    }
}