package gra;

public class Hammer extends Item {
    public Hammer() {
        name = "Mlotek";
        rarity = "pospolity";
        desc = "Mlotek, ktory zadaje duzo obrazen";
        accuracy = 60;
        damage = 20;
        points = 1;
    }
}
