package gra;
import java.util.ArrayList;

public class Equipment {
    public static final String blue = "\u001B[34m";
    public static final String reset_color = "\u001B[0m";
    public ArrayList<Item> Items_array = new ArrayList<Item>();
    Main main = new Main();

    public void printListName(){
        for(int x=0; x<Items_array.size(); x++) {
            System.out.println(blue + "•" + Items_array.get(x).getName() + reset_color);
            System.out.println("  Rzadkosc: " + Items_array.get(x).getRarity());
            System.out.println("  Opis: " + Items_array.get(x).getDesc());
            System.out.println("  Celnosc: " + Items_array.get(x).getAccuracy() + "%");
            System.out.println("  Atak: " + Items_array.get(x).getDamage());
            System.out.println("  Punkty: " + Items_array.get(x).getPoints());
        }
    }

    public void printEq() {
        System.out.println();
        main.breaks();
        System.out.println("Ekwipunek: ");
        printListName();
        main.breaks();
        System.out.println();
    }
}