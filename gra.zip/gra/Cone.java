package gra;

public class Cone extends Item {
    public Cone() {
        name = "Szyszka";
        rarity = "pospolity";
        desc = "Zwykla szyszka, ktora znalazles na ziemi";
        accuracy = 40;
        damage = 5;
        points = 1;
    }
}